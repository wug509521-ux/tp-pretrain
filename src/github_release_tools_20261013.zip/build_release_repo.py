#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build a clean, allowlisted GitHub staging repository.

The script never copies the full project tree. Every model, data, baseline and
result artifact must be supplied explicitly as NAME=PATH.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path


DATA_DIRS = [
    "pretraining",
    "environmental_domain",
    "activated_sludge",
    "external_single_step_111",
    "external_multistep_1910_855",
    "wastewater_validation_571",
    "batch_experiments_72h",
    "hrms_processed",
    "figure_source_data",
    "supplementary_tables",
    "manifests",
]


DEFAULT_SCRIPTS = [
    "predict_baseline_multi_smiles.py",
    "predict_fusion_oofhead_newmergedc3tail.py",
    "supervised_fusion_multistep.py",
    "evaluate_fusion_reliability.py",
]


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            block = handle.read(chunk_size)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def parse_mapping(values: list[str], label: str) -> list[tuple[str, Path]]:
    result: list[tuple[str, Path]] = []
    for value in values:
        if "=" not in value:
            raise SystemExit(f"{label} must use NAME=PATH: {value}")
        name, raw_path = value.split("=", 1)
        name = name.strip()
        path = Path(raw_path).expanduser().resolve()
        if not name or not path.exists():
            raise SystemExit(f"invalid {label}: {value}")
        result.append((name, path))
    return result


def copy_item(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if source.is_dir():
        if destination.exists():
            raise SystemExit(f"refusing to overwrite copied directory: {destination}")
        shutil.copytree(source, destination, symlinks=False)
    else:
        shutil.copy2(source, destination)


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def public_source_name(source: Path, project_root: Path) -> str:
    """Return a non-sensitive source label for the public manifest."""
    try:
        return str(source.resolve().relative_to(project_root.resolve())).replace("\\", "/")
    except ValueError:
        return f"external/{source.name}"


def write_scaffold(repo: Path) -> None:
    for directory in [
        "models",
        "baselines",
        "configs",
        "scripts",
        "src",
        "results",
        "docs",
        "tests",
    ]:
        (repo / directory).mkdir(parents=True, exist_ok=True)
    for directory in DATA_DIRS:
        (repo / "data" / directory).mkdir(parents=True, exist_ok=True)

    write_text(
        repo / ".gitignore",
        """__pycache__/\n*.py[cod]\n.venv/\n.env\n*.log\n*.tmp\nruns/\noutputs/\ncache/\n.DS_Store\n""",
    )
    write_text(
        repo / "LICENSE_PENDING.md",
        """# License selection required before public release\n\nChoose and add the approved code license before publishing this repository.\nDo not replace this file with an invented license or a third-party license.\n""",
    )
    write_text(
        repo / "CITATION.cff",
        """cff-version: 1.2.0\ntitle: "TP Pretrain Reproducibility Package"\ntype: software\nmessage: "Please cite the associated manuscript and this exact release."\nauthors:\n  - family-names: "TODO"\n    given-names: "TODO"\nversion: "v0.1.0"\ndoi: "TODO"\n""",
    )
    write_text(
        repo / "data" / "README.md",
        """# Data release\n\nThis directory is organized by modelling stage and evaluation task. Each dataset must be accompanied by provenance, license/access information, a data dictionary and a SHA256 manifest.\n\nThe 111-reaction single-step benchmark is separate from the 1,910-product/855-parent multi-step validation set. The 494 and 552 activated-sludge counts must be explained as distinct processing stages if both are retained.\n\nRaw HRMS files, restricted third-party data and files without redistribution permission must not be copied here. In that case, keep only de-identified processed data and an access description.\n""",
    )
    write_text(
        repo / "docs" / "MODEL_MAPPING.md",
        """# Manuscript model mapping\n\n| Manuscript name | Repository directory | Checkpoint | Status |\n|---|---|---|---|\n| Model 1 | `models/model_1_no_pretraining` | TODO | confirm from audit |\n| Model 2 | `models/model_2_single_step_pretraining` | TODO | confirm from audit |\n| Model 3 | `models/model_3_two_step_pretraining` | TODO | confirm from audit |\n| Model 4 | `models/model_4_reaction_site_assisted` | TODO | confirm from audit |\n| Fusion/Ours | `models/fusion_final` | TODO | confirm head/tail and fusion rule |\n| Reaction-site oracle | `models/reaction_site_oracle` | TODO | upper-bound ablation only |\n\nDo not fill this table from directory names alone. Record the exact checkpoint, tokenizer, configuration and SHA256 after verification.\n""",
    )
    write_text(
        repo / "docs" / "EXTERNAL_BASELINES.md",
        """# External baseline provenance\n\nFor BioTransformer 3, enviRule and EnviFormer, record the exact release or commit, command line, input manifest, raw predictions, license and the canonical-SMILES evaluation script. If redistribution of the executable is not allowed, provide the official download location and keep the generated prediction table used by the manuscript.\n""",
    )
    write_text(
        repo / "docs" / "DATA_AVAILABILITY.md",
        """# Data availability checklist\n\nBefore public release, classify every dataset as public, reused public, third-party restricted, controlled access or not releasable. Do not claim that restricted data are public. Record the source, license, stable identifier, checksum and the exact files needed to reproduce each manuscript table and figure.\n""",
    )


def write_readme(repo: Path, copied: list[dict]) -> None:
    lines = [
        "# TP Pretrain Reproducibility Package",
        "",
        "This repository contains the code, configurations, approved model artifacts and source data needed to reproduce the associated TP prediction study.",
        "",
        "## Reproducibility status",
        "",
        "This staging repository was generated from an allowlist. Review every TODO, model mapping, license and data-access statement before making it public.",
        "",
        "## Model names",
        "",
        "See `docs/MODEL_MAPPING.md`. The repository must distinguish Model 1–4, the final Fusion model and the reaction-site oracle ablation.",
        "",
        "## Data",
        "",
        "See `data/README.md`. The single-step 111-reaction benchmark and the 1,910-product/855-parent multi-step validation set are separate datasets.",
        "",
        "## External baselines",
        "",
        "See `docs/EXTERNAL_BASELINES.md` for BioTransformer 3, enviRule and EnviFormer provenance.",
        "",
        "## Included artifacts",
        "",
    ]
    if copied:
        for row in copied:
            lines.append(f"- `{row['destination']}` from `{row['source_name']}`")
    else:
        lines.append("- No project artifacts copied yet; add explicit mappings with `build_release_repo.py`.")
    lines.extend(
        [
            "",
            "## Publication gate",
            "",
            "Before publishing, add the approved LICENSE, complete CITATION.cff, remove all TODO entries, run the smoke test in a clean environment, inspect SHA256SUMS.txt and scan for secrets and absolute local paths.",
            "",
        ]
    )
    write_text(repo / "README.md", "\n".join(lines))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", required=True, type=Path)
    parser.add_argument("--audit-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--model", action="append", default=[], help="NAME=PATH")
    parser.add_argument("--data-source", action="append", default=[], help="NAME=PATH")
    parser.add_argument("--baseline-source", action="append", default=[], help="NAME=PATH")
    parser.add_argument("--result-source", action="append", default=[], help="NAME=PATH")
    parser.add_argument("--copy-script", action="append", default=[], help="project-relative script path")
    args = parser.parse_args()

    root = args.project_root.expanduser().resolve()
    audit_dir = args.audit_dir.expanduser().resolve()
    if not root.is_dir():
        raise SystemExit(f"project root does not exist: {root}")
    if not audit_dir.is_dir():
        raise SystemExit(f"audit directory does not exist: {audit_dir}")
    repo = args.output_dir.expanduser().resolve()
    if repo.exists() and any(repo.iterdir()):
        raise SystemExit(f"refusing to overwrite non-empty output directory: {repo}")
    repo.mkdir(parents=True, exist_ok=False)
    write_scaffold(repo)

    copied: list[dict] = []

    # Copy source code only from explicit or conservative known entrypoints.
    script_names = list(args.copy_script)
    if not script_names:
        script_names = [name for name in DEFAULT_SCRIPTS if (root / "scripts" / name).exists()]
    for relative in script_names:
        source = (root / relative).resolve()
        if not source.exists():
            source = (root / "scripts" / relative).resolve()
        if not source.is_file():
            raise SystemExit(f"script not found: {relative}")
        destination = repo / "scripts" / source.name
        copy_item(source, destination)
        copied.append({"kind": "script", "source_name": public_source_name(source, root), "destination": str(destination.relative_to(repo))})

    # Configurations and source package are copied only when present.
    for relative, target in [("configs", "configs"), ("src", "src")]:
        source = root / relative
        if source.is_dir():
            for item in sorted(source.rglob("*")):
                if item.is_file() and "__pycache__" not in item.parts:
                    destination = repo / target / item.relative_to(source)
                    copy_item(item, destination)
                    copied.append({"kind": relative, "source_name": public_source_name(item, root), "destination": str(destination.relative_to(repo))})

    mappings = [
        ("model", parse_mapping(args.model, "--model"), "models"),
        ("data", parse_mapping(args.data_source, "--data-source"), "data"),
        ("baseline", parse_mapping(args.baseline_source, "--baseline-source"), "baselines"),
        ("result", parse_mapping(args.result_source, "--result-source"), "results"),
    ]
    for kind, pairs, target_root in mappings:
        for name, source in pairs:
            destination = repo / target_root / name
            copy_item(source, destination)
            copied.append({"kind": kind, "source_name": public_source_name(source, root), "destination": str(destination.relative_to(repo))})

    write_readme(repo, copied)

    manifest_rows: list[dict] = []
    hash_lines: list[str] = []
    for item in sorted(repo.rglob("*")):
        if not item.is_file() or item.name in {"SHA256SUMS.txt", "release_manifest.json"}:
            continue
        digest = sha256_file(item)
        relative = str(item.relative_to(repo)).replace("\\", "/")
        manifest_rows.append({"path": relative, "size_bytes": item.stat().st_size, "sha256": digest})
        hash_lines.append(f"{digest}  {relative}")

    manifest = {
        "status": "STAGING_CREATED",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "project_root_not_public": True,
        "audit_dir": audit_dir.name,
        "copied_artifacts": copied,
        "files": manifest_rows,
        "notes": [
            "This is a staging repository, not a publication approval.",
            "Review licenses, TODO entries, model mapping and data access before pushing.",
            "No complete project tree was copied.",
        ],
    }
    write_text(repo / "release_manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    write_text(repo / "SHA256SUMS.txt", "\n".join(hash_lines) + "\n")
    print(json.dumps({"status": "STAGING_CREATED", "output_dir": str(repo), "n_files": len(manifest_rows)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

