# Manuscript and SI release checklist

This checklist is based on `Manuscript_1013.docx` and `SI_20261010.docx`. It is a release checklist, not evidence that every artifact is already present on the server.

## Model artifacts

- [ ] Model 1: no pretraining
- [ ] Model 2: single-step pretraining
- [ ] Model 3: two-step pretraining
- [ ] Model 4: predicted-reaction-site-assisted model
- [ ] Final reaction-site-assisted Fusion model
- [ ] Reaction-site oracle upper-bound ablation, if numerical results are reported
- [ ] For every model: checkpoint, tokenizer, config, generation config, training config and SHA256

## External baselines

- [ ] BioTransformer 3: version, command, license, input manifest and raw predictions
- [ ] enviRule: version, command, license, input manifest and raw predictions
- [ ] EnviFormer refined implementation: release or commit, command and raw predictions
- [ ] Canonical-SMILES matching and Top-k evaluation script

## Data

- [ ] General pretraining corpus: 984,064 cleaned pairs
- [ ] Environmental-domain adaptation data: 4,670 pairs, 4,203/467 split
- [ ] Activated-sludge data: 552 cleaned pairs, 331/110/111 split
- [ ] Fixed single-step benchmark: 111 reactions
- [ ] External multi-step validation: 1,910 products from 855 parents
- [ ] Wastewater prediction inventory: 571 parents and 16,329 predicted TPs
- [ ] 72-h batch experiment data and metadata
- [ ] De-identified processed HRMS/MS data and annotation table

## Figure and table source data

- [ ] Figure 2 EC classification and UMAP source data
- [ ] Figure 3 Model 1–4 and Fusion metrics
- [ ] Figure 4 Fusion versus external baselines
- [ ] Figure 5 attention source data and QA summary
- [ ] Figure S1 six representative reactions and all model outputs
- [ ] Figure S2 Tanimoto pair-level data
- [ ] Tables S1–S6 as CSV/TSV or reproducible workbook sources
- [ ] Scripts that regenerate every figure and table

## Blocking manuscript discrepancies

- [ ] Resolve `enviPath` versus `enviRule` in the main text
- [ ] Explain 494 versus 552 activated-sludge counts
- [ ] Replace or define the phrase `Union model`
- [ ] Keep the 111 single-step benchmark separate from the 1,910/855 multi-step set
- [ ] Map Model 1–4 and Fusion names consistently across main text, SI and repository

## Files that must not be copied automatically

- [ ] Full historical `runs/` directory
- [ ] Temporary logs, caches and notebooks
- [ ] Absolute Windows/server paths
- [ ] Credentials, tokens and private keys
- [ ] Third-party files without redistribution permission
- [ ] Raw HRMS files or restricted sample metadata without approval

