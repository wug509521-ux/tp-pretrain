#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Audit a TP-pretrain project before creating a public reproducibility repo.

This script is intentionally read-only with respect to the source project. It
writes only to --output-dir and does not infer a final model mapping from run
directory names.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable


MODEL_KEYS = [
    "model_1_no_pretraining",
    "model_2_single_step_pretraining",
    "model_3_two_step_pretraining",
    "model_4_reaction_site_assisted",
    "fusion_final",
    "reaction_site_oracle",
]

BASELINE_KEYS = ["biotransformer3", "envirule", "enviformer"]

REQUIRED_ITEMS = [
    ("model", key, "manual mapping required; do not infer from run name")
    for key in MODEL_KEYS
] + [
    ("baseline", key, "version, command, input manifest and raw predictions required")
    for key in BASELINE_KEYS
] + [
    ("dataset", "general_pretraining_984064", "record exact cleaned count and provenance"),
    ("dataset", "environmental_domain_4670", "record 4203/467 split and provenance"),
    ("dataset", "activated_sludge_552", "record 331/110/111 split and provenance"),
    ("dataset", "external_single_step_111", "fixed single-step benchmark"),
    ("dataset", "external_multistep_1910_855", "external multi-step validation"),
    ("dataset", "wastewater_validation_571", "571 parents and 16329 predicted TPs"),
    ("dataset", "batch_experiments_72h", "raw or processed batch validation data"),
    ("dataset", "hrms_processed", "de-identified processed HRMS/MS data"),
    ("result", "figure_2_source_data", "EC classification and UMAP source data"),
    ("result", "figure_3_source_data", "ablation metrics source data"),
    ("result", "figure_4_source_data", "external comparison source data"),
    ("result", "figure_5_source_data", "attention source data and QA"),
    ("result", "figure_S1_source_data", "six representative reactions"),
    ("result", "figure_S2_source_data", "Tanimoto similarity pairs"),
    ("code", "training_and_preprocessing", "training, standardization and split code"),
    ("code", "site_predictor_and_fusion", "AutoSOM, OOF site predictor and Fusion code"),
    ("code", "evaluation_and_plotting", "metrics and figure regeneration code"),
]


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            block = handle.read(chunk_size)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def write_csv(path: Path, rows: list[dict], fieldnames: list[str]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def files_under(path: Path) -> Iterable[Path]:
    if path.is_file():
        yield path
        return
    if not path.is_dir():
        return
    for item in sorted(path.rglob("*")):
        if item.is_file() and "__pycache__" not in item.parts:
            yield item


def safe_rel(path: Path, root: Path) -> str:
    try:
        return str(path.resolve().relative_to(root.resolve()))
    except ValueError:
        return str(path.resolve())


def discover_model_candidates(root: Path) -> list[dict]:
    candidates: list[dict] = []
    seen: set[str] = set()
    patterns = [
        "runs/**/checkpoints/best",
        "runs/**/model_compat/head",
        "runs/**/model_compat/tail",
    ]
    for pattern in patterns:
        for path in sorted(root.glob(pattern)):
            if not path.exists() or str(path.resolve()) in seen:
                continue
            seen.add(str(path.resolve()))
            files = list(files_under(path))
            total_size = sum(item.stat().st_size for item in files)
            candidates.append(
                {
                    "path": safe_rel(path, root),
                    "absolute_path": str(path.resolve()),
                    "kind": "directory",
                    "n_files": len(files),
                    "size_bytes": total_size,
                    "mapping_status": "unassigned",
                }
            )
    return candidates


def discover_scripts(root: Path) -> list[dict]:
    rows: list[dict] = []
    scripts = root / "scripts"
    if not scripts.exists():
        return rows
    for path in sorted(scripts.iterdir()):
        if path.is_file() and path.suffix.lower() in {".py", ".r", ".sh", ".yaml", ".yml"}:
            rows.append(
                {
                    "category": "script_or_config",
                    "path": safe_rel(path, root),
                    "size_bytes": path.stat().st_size,
                    "suffix": path.suffix.lower(),
                }
            )
    return rows


def discover_data_candidates(root: Path) -> list[dict]:
    rows: list[dict] = []
    search_roots = [root / "data", root / "inputs", root / "configs"]
    suffixes = {".csv", ".tsv", ".json", ".jsonl", ".xlsx", ".xls", ".parquet", ".yaml", ".yml"}
    for base in search_roots:
        if not base.exists():
            continue
        for path in files_under(base):
            if path.suffix.lower() in suffixes:
                rows.append(
                    {
                        "category": "data_or_config",
                        "path": safe_rel(path, root),
                        "size_bytes": path.stat().st_size,
                        "suffix": path.suffix.lower(),
                    }
                )
    return rows


def discover_results(root: Path) -> list[dict]:
    rows: list[dict] = []
    runs = root / "runs"
    if not runs.exists():
        return rows
    for path in sorted(runs.iterdir()):
        if path.is_dir():
            rows.append(
                {
                    "category": "run_directory",
                    "path": safe_rel(path, root),
                    "size_bytes": sum(item.stat().st_size for item in files_under(path)),
                    "note": "historical run; do not copy wholesale",
                }
            )
    return rows


def read_docx_text(path: Path) -> str:
    try:
        from docx import Document  # type: ignore
    except Exception:
        return ""
    try:
        document = Document(str(path))
        parts = [paragraph.text for paragraph in document.paragraphs]
        for table in document.tables:
            for row in table.rows:
                parts.append(" | ".join(cell.text for cell in row.cells))
        return "\n".join(parts)
    except Exception:
        return ""


def document_evidence(manuscript: Path | None, si: Path | None) -> list[dict]:
    rows: list[dict] = []
    patterns = {
        "model_names": r"Model 1|Model 2|Model 3|Model 4|Fusion|reaction-site oracle",
        "external_baselines": r"BioTransformer|enviRule|enviPath|EnviFormer",
        "dataset_counts": r"494|552|984,064|4,670|111|1,910|855|571|16,329",
        "figure_and_table_sources": r"Figure [2-5]|Figure S[1-2]|Table S[1-6]",
    }
    for label, path in [("manuscript", manuscript), ("si", si)]:
        if path is None:
            continue
        text = read_docx_text(path)
        for name, pattern in patterns.items():
            matches = sorted(set(re.findall(pattern, text, flags=re.I)))
            rows.append(
                {
                    "document": label,
                    "path": str(path.resolve()),
                    "evidence_type": name,
                    "matches": "; ".join(matches),
                    "status": "found" if matches else "not_found",
                }
            )
    return rows


def build_required_rows(root: Path, model_candidates: list[dict], scripts: list[dict], data: list[dict]) -> list[dict]:
    model_paths = {row["path"] for row in model_candidates}
    script_text = " ".join(row["path"].lower() for row in scripts)
    data_text = " ".join(row["path"].lower() for row in data)
    rows: list[dict] = []
    for category, key, note in REQUIRED_ITEMS:
        if category == "model":
            status = "manual_mapping_required"
            evidence = f"{len(model_paths)} model directories discovered"
        elif category == "baseline":
            status = "manual_mapping_required"
            evidence = "wrapper/version/raw-output audit required"
        elif category == "code":
            status = "candidate_found" if script_text else "missing_candidate"
            evidence = "scripts directory scanned"
        elif category == "dataset":
            status = "candidate_found" if data_text else "missing_candidate"
            evidence = "data/inputs/configs scanned"
        else:
            status = "manual_mapping_required"
            evidence = "results must be explicitly selected"
        rows.append(
            {
                "category": category,
                "required_item": key,
                "status": status,
                "evidence": evidence,
                "notes": note,
            }
        )
    return rows


def write_gap_report(path: Path, root: Path, summary: dict) -> None:
    lines = [
        "# GitHub release gap report",
        "",
        f"Source project: `{root}`",
        f"Generated at: `{summary['generated_at']}`",
        "",
        "## Blocking issues",
        "",
        "- Model 1–4, Fusion and reaction-site oracle still require explicit checkpoint mapping.",
        "- `enviPath` versus `enviRule` must be resolved before publishing the comparator package.",
        "- The 494 versus 552 activated-sludge counts must be documented as separate processing stages or corrected.",
        "- The 111 single-step benchmark and 1,910/855 multi-step validation set must remain separate.",
        "- Third-party baseline versions, commands, licenses and raw outputs must be recorded.",
        "- Data licensing and HRMS confidentiality must be checked before copying any raw data.",
        "",
        "## Do not copy automatically",
        "",
        "- the complete `runs/` directory;",
        "- temporary logs and caches;",
        "- absolute server or Windows paths;",
        "- secrets, credentials, private keys and third-party files without redistribution permission.",
        "",
        "## Next action",
        "",
        "Review `required_items.csv` and fill the model, baseline, data and result mappings before running `build_release_repo.py`.",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--manuscript", type=Path)
    parser.add_argument("--si", type=Path)
    parser.add_argument("--hash-checkpoints", action="store_true")
    parser.add_argument("--max-hash-mb", type=int, default=2048)
    args = parser.parse_args()

    root = args.project_root.expanduser().resolve()
    if not root.is_dir():
        raise SystemExit(f"project root does not exist: {root}")
    out = args.output_dir.expanduser().resolve()
    out.mkdir(parents=True, exist_ok=False)

    model_candidates = discover_model_candidates(root)
    scripts = discover_scripts(root)
    data_candidates = discover_data_candidates(root)
    result_candidates = discover_results(root)
    required = build_required_rows(root, model_candidates, scripts, data_candidates)
    evidence = document_evidence(args.manuscript, args.si)

    hash_rows: list[dict] = []
    if args.hash_checkpoints:
        max_bytes = args.max_hash_mb * 1024 * 1024
        for candidate in model_candidates:
            directory = Path(candidate["absolute_path"])
            for file_path in files_under(directory):
                if file_path.stat().st_size <= max_bytes:
                    hash_rows.append(
                        {
                            "sha256": sha256_file(file_path),
                            "path": safe_rel(file_path, root),
                            "size_bytes": file_path.stat().st_size,
                        }
                    )
                else:
                    hash_rows.append(
                        {
                            "sha256": "SKIPPED_LARGE_FILE",
                            "path": safe_rel(file_path, root),
                            "size_bytes": file_path.stat().st_size,
                        }
                    )

    write_csv(
        out / "required_items.csv",
        required,
        ["category", "required_item", "status", "evidence", "notes"],
    )
    write_csv(
        out / "model_candidates.csv",
        model_candidates,
        ["path", "absolute_path", "kind", "n_files", "size_bytes", "mapping_status"],
    )
    write_csv(
        out / "artifact_inventory.csv",
        scripts + data_candidates + result_candidates,
        ["category", "path", "size_bytes", "suffix", "note"],
    )
    write_csv(
        out / "document_evidence.csv",
        evidence,
        ["document", "path", "evidence_type", "matches", "status"],
    )
    write_csv(out / "checkpoint_hashes.csv", hash_rows, ["sha256", "path", "size_bytes"])

    summary = {
        "status": "AUDITED",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "project_root": str(root),
        "n_model_candidates": len(model_candidates),
        "n_scripts": len(scripts),
        "n_data_candidates": len(data_candidates),
        "n_run_directories": len(result_candidates),
        "n_required_items": len(required),
        "n_document_evidence_rows": len(evidence),
        "notes": [
            "No final model mapping was inferred from run names.",
            "The audit does not modify the source project.",
            "The build step must use explicit allowlisted mappings.",
        ],
    }
    (out / "audit_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    write_gap_report(out / "release_gap_report.md", root, summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"audit_dir: {out}")


if __name__ == "__main__":
    main()

