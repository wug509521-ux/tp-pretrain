# TP Pretrain GitHub Release Tools

这是一套在服务器上运行的发布整理工具。它先审计项目中的实际代码、配置、checkpoint、数据和结果，再按白名单创建一个干净的 GitHub 发布目录。

工具不会自动把整个项目、历史 `runs/`、临时日志或个人路径复制进仓库。模型、数据、外部对照结果和图表源数据都需要通过明确的映射参数加入。

`PAPER_ARTIFACT_CHECKLIST.md` 按正文和 SI 列出了必须核对的模型、数据、外部基线、图表源数据和论文不一致项。

## 1. 只做审计

```bash
conda activate tp_pretrain

ROOT=/data/fsy2/jmx/tp_pretrain_project
PY="$CONDA_PREFIX/bin/python"
AUDIT="$ROOT/runs/github_release_audit_$(date +%Y%m%d_%H%M%S)"

"$PY" audit_release_project.py \
  --project-root "$ROOT" \
  --output-dir "$AUDIT"
```

如正文和 SI 也已经放在服务器上，可追加：

```bash
  --manuscript /path/to/Manuscript_1013.docx \
  --si /path/to/SI_20261010.docx
```

审计只写入 `AUDIT`，不会修改原项目。重点查看：

```text
required_items.csv
model_candidates.csv
artifact_inventory.csv
release_gap_report.md
audit_summary.json
```

## 2. 创建 GitHub 仓库草稿

建议先创建新的 staging 目录，不要把输出写回原项目：

```bash
REPO="$ROOT/github/tp-pretrain-reproducibility"

"$PY" build_release_repo.py \
  --project-root "$ROOT" \
  --audit-dir "$AUDIT" \
  --output-dir "$REPO" \
  --model model_1_no_pretraining="$ROOT/runs/<confirmed_model_1_checkpoint>" \
  --model model_2_single_step_pretraining="$ROOT/runs/<confirmed_model_2_checkpoint>" \
  --model model_3_two_step_pretraining="$ROOT/runs/<confirmed_model_3_checkpoint>" \
  --model model_4_reaction_site_assisted="$ROOT/runs/<confirmed_model_4_checkpoint>" \
  --model fusion_final="$ROOT/runs/<confirmed_fusion_model_or_directory>"
```

模型路径必须先根据 `model_candidates.csv` 和论文最终实验记录确认，不能根据运行目录名称猜测。

数据和外部对照结果通过显式参数加入，例如：

```bash
  --data-source activated_sludge="$ROOT/data/processed/<confirmed_sludge_dataset>" \
  --data-source external_single_step_111="$ROOT/data/processed/<confirmed_111_test_set>" \
  --data-source external_multistep_1910_855="$ROOT/data/processed/<confirmed_external_set>" \
  --baseline-source biotransformer3="$ROOT/results/<biotransformer_outputs>" \
  --baseline-source envirule="$ROOT/results/<envirule_outputs>" \
  --baseline-source enviformer="$ROOT/results/<enviformer_outputs>"
```

如果没有传入模型或数据映射，工具仍会创建完整目录和说明文件，但不会伪造模型或数据文件。

## 3. 发布前检查

在 staging 目录中确认：

```bash
cd "$REPO"
cat release_manifest.json
cat SHA256SUMS.txt
git status --short
```

确认无敏感信息后再初始化 Git、配置 Git LFS、提交和推送。`LICENSE_PENDING.md`、`CITATION.cff` 和 README 中的 TODO 必须在公开前填写完成。

